#include <mpi.h>
#include <stdio.h>
#include<math.h>
int main(int argc, char** argv) {
    int x = 2; // Constant value
    int rank;
    int result;

    // Initialize MPI
    MPI_Init(NULL, NULL);

    // Get the current process's rank
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    // Calculate the power of x for this process
    result = pow(x, rank);

    // Print the result
    printf("Process %d: %d^%d = %d\n", rank, x, rank, result);

    // Barrier to synchronize all processes
    MPI_Barrier(MPI_COMM_WORLD);

    // Finalize MPI
    MPI_Finalize();

    return 0;
}